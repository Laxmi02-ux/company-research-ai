import { NextRequest, NextResponse } from "next/server";
import { generatePdfBuffer } from "@/lib/pdfGenerator";
import { ResearchReport } from "@/lib/types";

export async function POST(req: NextRequest) {
  try {
    const report: ResearchReport = await req.json();
    const buffer = await generatePdfBuffer(report);

    const filename = `${(report.companyName || "company").replace(/[^a-z0-9]+/gi, "-")}-dossier.pdf`;

    return new NextResponse(buffer, {
      status: 200,
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": `attachment; filename="${filename}"`,
      },
    });
  } catch (err: any) {
    console.error(err);
    return NextResponse.json({ error: err?.message || "PDF generation failed." }, { status: 500 });
  }
}
