import { NextRequest, NextResponse } from "next/server";
import { generatePdfBuffer } from "@/lib/pdfGenerator";
import { ResearchReport } from "@/lib/types";

/**
 * Sends the applicant + research summary and the generated PDF
 * to a Discord channel via the Discord Bot REST API.
 *
 * Body: {
 *   botToken: string,
 *   channelId: string,
 *   applicantName: string,
 *   applicantEmail: string,
 *   report: ResearchReport
 * }
 *
 * Bot token & channel ID are provided at request time from the
 * client's Discord settings page (session-only) — nothing is
 * persisted server-side, per the "no database" requirement.
 */
export async function POST(req: NextRequest) {
  try {
    const { botToken, channelId, applicantName, applicantEmail, report } =
      (await req.json()) as {
        botToken: string;
        channelId: string;
        applicantName: string;
        applicantEmail: string;
        report: ResearchReport;
      };

    if (!botToken || !channelId) {
      return NextResponse.json(
        { error: "Discord Bot Token and Channel ID are required." },
        { status: 400 }
      );
    }
    if (!report) {
      return NextResponse.json({ error: "No report provided." }, { status: 400 });
    }

    const pdfBuffer = await generatePdfBuffer(report);
    const filename = `${(report.companyName || "company").replace(/[^a-z0-9]+/gi, "-")}-dossier.pdf`;

    const content = [
      `**New Research Submission**`,
      `**Applicant:** ${applicantName || "N/A"}`,
      `**Email:** ${applicantEmail || "N/A"}`,
      `**Company:** ${report.companyName}`,
      `**Website:** ${report.website}`,
    ].join("\n");

    const form = new FormData();
    form.append("payload_json", JSON.stringify({ content }));
    form.append(
      "files[0]",
      new Blob([pdfBuffer], { type: "application/pdf" }),
      filename
    );

    const res = await fetch(
      `https://discord.com/api/v10/channels/${channelId}/messages`,
      {
        method: "POST",
        headers: { Authorization: `Bot ${botToken}` },
        body: form,
      }
    );

    if (!res.ok) {
      const errText = await res.text();
      return NextResponse.json(
        { error: `Discord API error: ${res.status} ${errText}` },
        { status: 502 }
      );
    }

    return NextResponse.json({ success: true });
  } catch (err: any) {
    console.error(err);
    return NextResponse.json({ error: err?.message || "Discord send failed." }, { status: 500 });
  }
}
