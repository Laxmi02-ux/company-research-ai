import { NextRequest, NextResponse } from "next/server";
import {
  findOfficialWebsite,
  searchCompanyInfo,
  searchCompetitors,
  SerperResult,
} from "@/lib/serper";
import { crawlWebsite } from "@/lib/crawler";
import { analyzeCompany } from "@/lib/openrouter";
import { ResearchReport } from "@/lib/types";

export const maxDuration = 60;

function isUrl(input: string): boolean {
  try {
    const u = new URL(input.startsWith("http") ? input : `https://${input}`);
    return !!u.hostname.includes(".");
  } catch {
    return false;
  }
}

function normalizeToUrl(input: string): string {
  return input.startsWith("http") ? input : `https://${input}`;
}

function snippetsToText(results: SerperResult[]): string {
  return results
    .map((r) => `- ${r.title}: ${r.snippet ?? ""} (${r.link})`)
    .join("\n");
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const query: string = (body.query || "").trim();
    const model: string = body.model || "openai/gpt-4o-mini";

    if (!query) {
      return NextResponse.json({ error: "Please provide a company name or website URL." }, { status: 400 });
    }

    const sources: string[] = [];
    let websiteUrl: string;
    let companyNameGuess: string;
    let discoveryResults: SerperResult[] = [];

    if (isUrl(query)) {
      websiteUrl = normalizeToUrl(query);
      companyNameGuess = new URL(websiteUrl).hostname.replace(/^www\./, "").split(".")[0];
    } else {
      companyNameGuess = query;
      const { website, results } = await findOfficialWebsite(query);
      discoveryResults = results;
      if (!website) {
        return NextResponse.json(
          { error: `Could not find an official website for "${query}". Try entering the URL directly.` },
          { status: 404 }
        );
      }
      websiteUrl = website;
    }
    sources.push(websiteUrl);

    // 1. Crawl the website
    const pages = await crawlWebsite(websiteUrl);
    const crawledText = pages
      .map((p) => `### ${p.title} (${p.url})\n${p.text}`)
      .join("\n\n");
    pages.forEach((p) => sources.push(p.url));

    // 2. Gather public info + competitor search via Serper
    const [infoResults, competitorSeedResults] = await Promise.all([
      searchCompanyInfo(companyNameGuess).catch(() => [] as SerperResult[]),
      searchCompetitors(companyNameGuess, "").catch(() => [] as SerperResult[]),
    ]);

    const searchSnippets = snippetsToText([
      ...discoveryResults,
      ...infoResults,
      ...competitorSeedResults,
    ]);

    // 3. AI analysis via OpenRouter
    const analysis = await analyzeCompany({
      companyNameGuess,
      websiteUrl,
      crawledText: crawledText || "(No crawlable content found on this website.)",
      searchSnippets,
      model,
    });

    const report: ResearchReport = {
      companyName: analysis.companyName || companyNameGuess,
      website: websiteUrl,
      phone: analysis.phone || "",
      address: analysis.address || "",
      summary: analysis.summary || "",
      products: analysis.products || [],
      painPoints: analysis.painPoints || [],
      competitors: analysis.competitors || [],
      sources: Array.from(new Set(sources)),
      model,
      generatedAt: new Date().toISOString(),
    };

    return NextResponse.json({ report });
  } catch (err: any) {
    console.error(err);
    return NextResponse.json(
      { error: err?.message || "Something went wrong during research." },
      { status: 500 }
    );
  }
}
