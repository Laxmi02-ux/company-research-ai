"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { ResearchReport } from "@/lib/types";

export default function SettingsPage() {
  const [botToken, setBotToken] = useState("");
  const [channelId, setChannelId] = useState("");
  const [applicantName, setApplicantName] = useState("");
  const [applicantEmail, setApplicantEmail] = useState("");
  const [saved, setSaved] = useState(false);
  const [sending, setSending] = useState(false);
  const [status, setStatus] = useState<{ ok: boolean; msg: string } | null>(null);
  const [lastReport, setLastReport] = useState<ResearchReport | null>(null);

  useEffect(() => {
    // Session-only persistence — no server-side storage, per spec.
    const cfg = sessionStorage.getItem("discordConfig");
    if (cfg) {
      const parsed = JSON.parse(cfg);
      setBotToken(parsed.botToken || "");
      setChannelId(parsed.channelId || "");
      setApplicantName(parsed.applicantName || "");
      setApplicantEmail(parsed.applicantEmail || "");
    }
    const report = sessionStorage.getItem("lastReport");
    if (report) setLastReport(JSON.parse(report));
  }, []);

  function handleSave() {
    sessionStorage.setItem(
      "discordConfig",
      JSON.stringify({ botToken, channelId, applicantName, applicantEmail })
    );
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  }

  async function handleSendNow() {
    if (!lastReport) return;
    setSending(true);
    setStatus(null);
    try {
      const res = await fetch("/api/discord", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          botToken,
          channelId,
          applicantName,
          applicantEmail,
          report: lastReport,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to send to Discord.");
      setStatus({ ok: true, msg: "Sent to Discord successfully." });
    } catch (e: any) {
      setStatus({ ok: false, msg: e.message });
    } finally {
      setSending(false);
    }
  }

  return (
    <div className="min-h-screen px-5 py-8">
      <div className="mx-auto max-w-lg">
        <Link href="/" className="text-xs text-muted hover:text-amber">
          ← Back to research
        </Link>

        <div className="case-label text-[10px] text-amber mt-4 mb-1">Bonus Feature</div>
        <h1 className="text-2xl font-bold mb-1">Discord Integration</h1>
        <p className="text-sm text-muted mb-6">
          After a report is generated, send the applicant details, company info, and the PDF
          straight to a Discord channel. Nothing here is stored on a server — it lives only in
          this browser session.
        </p>

        <div className="dossier-card p-5 space-y-4">
          <Field label="Discord Bot Token" value={botToken} onChange={setBotToken} type="password" placeholder="Bot XXXXXXXX.XXXXXX.XXXXXXXXXXXXXXXXXX" />
          <Field label="Discord Channel ID" value={channelId} onChange={setChannelId} placeholder="123456789012345678" />
          <div className="border-t border-line pt-4">
            <Field label="Applicant Name" value={applicantName} onChange={setApplicantName} placeholder="Your full name" />
          </div>
          <Field label="Applicant Email" value={applicantEmail} onChange={setApplicantEmail} placeholder="you@example.com" />

          <button
            onClick={handleSave}
            className="w-full bg-amber text-ink font-semibold text-sm px-4 py-2.5 rounded-md hover:brightness-110 transition"
          >
            {saved ? "Saved ✓" : "Save Configuration"}
          </button>
        </div>

        <div className="dossier-card p-5 mt-4">
          <div className="case-label text-[9px] text-muted mb-2">Last Generated Report</div>
          {lastReport ? (
            <>
              <div className="text-sm font-semibold">{lastReport.companyName}</div>
              <div className="text-xs text-teal mb-3">{lastReport.website}</div>
              <button
                onClick={handleSendNow}
                disabled={sending || !botToken || !channelId}
                className="w-full border border-line hover:border-amber hover:text-amber transition text-sm px-4 py-2 rounded-md disabled:opacity-40"
              >
                {sending ? "Sending…" : "Send this report to Discord"}
              </button>
              {status && (
                <div className={`text-xs mt-2 ${status.ok ? "text-teal" : "text-rose"}`}>{status.msg}</div>
              )}
            </>
          ) : (
            <div className="text-sm text-muted">
              No report yet — generate one from the research page first.
            </div>
          )}
        </div>

        <p className="text-[11px] text-muted mt-4">
          Note: in production, reports are sent automatically right after generation. This page
          also lets you trigger it manually for testing.
        </p>
      </div>
    </div>
  );
}

function Field({
  label,
  value,
  onChange,
  placeholder,
  type = "text",
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  type?: string;
}) {
  return (
    <div>
      <label className="case-label text-[9px] text-muted block mb-1">{label}</label>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="w-full bg-ink border border-line rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-amber"
      />
    </div>
  );
}
