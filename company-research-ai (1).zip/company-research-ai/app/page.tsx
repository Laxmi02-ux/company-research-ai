"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { AVAILABLE_MODELS } from "@/lib/openrouter";
import { ResearchReport } from "@/lib/types";

type Role = "user" | "assistant" | "system";
interface ChatMessage {
  id: string;
  role: Role;
  kind: "text" | "report" | "progress" | "error";
  text?: string;
  report?: ResearchReport;
}

const PROGRESS_STEPS = [
  "Searching public sources…",
  "Resolving official website…",
  "Crawling site: about, products, pricing, contact…",
  "Cross-referencing competitors…",
  "Running AI analysis…",
];

function uid() {
  return Math.random().toString(36).slice(2, 10);
}

export default function HomePage() {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: uid(),
      role: "assistant",
      kind: "text",
      text: "Give me a company name (e.g. \"Stripe\") or a website URL (e.g. \"https://stripe.com\") and I'll put together a full research dossier — summary, pain points, competitors, and a downloadable PDF.",
    },
  ]);
  const [input, setInput] = useState("");
  const [model, setModel] = useState(AVAILABLE_MODELS[0].id);
  const [loading, setLoading] = useState(false);
  const [progressIdx, setProgressIdx] = useState(0);
  const [downloading, setDownloading] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, loading]);

  useEffect(() => {
    if (!loading) return;
    const t = setInterval(() => {
      setProgressIdx((i) => (i + 1) % PROGRESS_STEPS.length);
    }, 1600);
    return () => clearInterval(t);
  }, [loading]);

  async function handleSend() {
    const query = input.trim();
    if (!query || loading) return;
    setInput("");
    setMessages((m) => [...m, { id: uid(), role: "user", kind: "text", text: query }]);
    setLoading(true);
    setProgressIdx(0);

    try {
      const res = await fetch("/api/research", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query, model }),
      });
      const data = await res.json();
      if (!res.ok) {
        setMessages((m) => [
          ...m,
          { id: uid(), role: "assistant", kind: "error", text: data.error || "Research failed." },
        ]);
      } else {
        setMessages((m) => [...m, { id: uid(), role: "assistant", kind: "report", report: data.report }]);
        // stash the latest report so the Discord settings page can access it
        try {
          sessionStorage.setItem("lastReport", JSON.stringify(data.report));
        } catch {}
        // If Discord is configured, automatically deliver the report.
        try {
          const cfgRaw = sessionStorage.getItem("discordConfig");
          if (cfgRaw) {
            const cfg = JSON.parse(cfgRaw);
            if (cfg.botToken && cfg.channelId) {
              fetch("/api/discord", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ ...cfg, report: data.report }),
              })
                .then((r) => r.json())
                .then((res) => {
                  setMessages((m) => [
                    ...m,
                    {
                      id: uid(),
                      role: "assistant",
                      kind: "text",
                      text: res.success
                        ? "Sent this dossier to your configured Discord channel."
                        : `Discord delivery failed: ${res.error}`,
                    },
                  ]);
                })
                .catch(() => {});
            }
          }
        } catch {}
      }
    } catch (e: any) {
      setMessages((m) => [
        ...m,
        { id: uid(), role: "assistant", kind: "error", text: e?.message || "Network error." },
      ]);
    } finally {
      setLoading(false);
    }
  }

  async function handleDownloadPdf(report: ResearchReport) {
    setDownloading(report.website);
    try {
      const res = await fetch("/api/pdf", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(report),
      });
      if (!res.ok) throw new Error("PDF generation failed");
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `${report.companyName.replace(/[^a-z0-9]+/gi, "-")}-dossier.pdf`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (e) {
      alert("Could not generate the PDF. Please try again.");
    } finally {
      setDownloading(null);
    }
  }

  return (
    <div className="flex h-screen flex-col">
      {/* Header */}
      <header className="flex items-center justify-between border-b border-line px-5 py-3.5 shrink-0">
        <div className="flex items-center gap-2.5">
          <div className="h-7 w-7 rounded-md bg-amber flex items-center justify-center font-mono text-ink text-sm font-bold">
            D
          </div>
          <div>
            <div className="text-sm font-semibold leading-none">Dossier</div>
            <div className="case-label text-[10px] text-muted leading-none mt-1">AI Company Research</div>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <select
            value={model}
            onChange={(e) => setModel(e.target.value)}
            className="bg-panel border border-line rounded-md text-xs px-2.5 py-1.5 text-paper focus:outline-none focus:ring-1 focus:ring-amber"
          >
            {AVAILABLE_MODELS.map((m) => (
              <option key={m.id} value={m.id}>
                {m.label}
              </option>
            ))}
          </select>
          <Link
            href="/settings"
            className="text-xs px-3 py-1.5 rounded-md border border-line hover:border-amber hover:text-amber transition-colors"
          >
            Discord Settings
          </Link>
        </div>
      </header>

      {/* Chat area */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto px-5 py-6">
        <div className="mx-auto max-w-3xl space-y-5">
          {messages.map((m) => (
            <MessageBubble key={m.id} m={m} onDownload={handleDownloadPdf} downloading={downloading} />
          ))}

          {loading && (
            <div className="rise-in flex items-start gap-3">
              <Avatar />
              <div className="dossier-card px-4 py-3 max-w-md">
                <div className="case-label text-[10px] text-amber mb-1">Working</div>
                <div className="text-sm text-paper">
                  {PROGRESS_STEPS[progressIdx]}
                  <span className="cursor-blink">▌</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Input */}
      <div className="border-t border-line px-5 py-4 shrink-0">
        <div className="mx-auto max-w-3xl flex items-center gap-2">
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSend()}
            placeholder="Company name or website URL…"
            disabled={loading}
            className="flex-1 bg-panel border border-line rounded-lg px-4 py-3 text-sm placeholder:text-muted focus:outline-none focus:ring-1 focus:ring-amber disabled:opacity-50"
          />
          <button
            onClick={handleSend}
            disabled={loading || !input.trim()}
            className="bg-amber text-ink font-semibold text-sm px-5 py-3 rounded-lg disabled:opacity-40 hover:brightness-110 transition"
          >
            Research
          </button>
        </div>
        <div className="mx-auto max-w-3xl mt-2 text-[11px] text-muted">
          Try: Stripe · Tesla · https://notion.so
        </div>
      </div>
    </div>
  );
}

function Avatar() {
  return (
    <div className="h-7 w-7 shrink-0 rounded-md bg-panel border border-line flex items-center justify-center font-mono text-[10px] text-amber">
      AI
    </div>
  );
}

function MessageBubble({
  m,
  onDownload,
  downloading,
}: {
  m: ChatMessage;
  onDownload: (r: ResearchReport) => void;
  downloading: string | null;
}) {
  if (m.role === "user") {
    return (
      <div className="rise-in flex justify-end">
        <div className="bg-panel border border-line rounded-lg px-4 py-2.5 max-w-md text-sm">{m.text}</div>
      </div>
    );
  }

  if (m.kind === "error") {
    return (
      <div className="rise-in flex items-start gap-3">
        <Avatar />
        <div className="dossier-card border-rose/40 px-4 py-3 max-w-md">
          <div className="case-label text-[10px] text-rose mb-1">Error</div>
          <div className="text-sm text-paper">{m.text}</div>
        </div>
      </div>
    );
  }

  if (m.kind === "report" && m.report) {
    return (
      <div className="rise-in flex items-start gap-3">
        <Avatar />
        <ReportCard report={m.report} onDownload={onDownload} downloading={downloading} />
      </div>
    );
  }

  return (
    <div className="rise-in flex items-start gap-3">
      <Avatar />
      <div className="dossier-card px-4 py-3 max-w-md text-sm text-paper">{m.text}</div>
    </div>
  );
}

function ReportCard({
  report,
  onDownload,
  downloading,
}: {
  report: ResearchReport;
  onDownload: (r: ResearchReport) => void;
  downloading: string | null;
}) {
  return (
    <div className="dossier-card px-5 py-4 w-full max-w-xl">
      <div className="flex items-start justify-between">
        <div>
          <div className="case-label text-[10px] text-amber mb-1">Research Dossier</div>
          <div className="text-lg font-bold">{report.companyName}</div>
          <a
            href={report.website}
            target="_blank"
            rel="noreferrer"
            className="text-xs text-teal hover:underline"
          >
            {report.website}
          </a>
        </div>
        <button
          onClick={() => onDownload(report)}
          disabled={downloading === report.website}
          className="text-xs bg-amber text-ink font-semibold px-3 py-1.5 rounded-md hover:brightness-110 disabled:opacity-50 shrink-0"
        >
          {downloading === report.website ? "Building PDF…" : "Download PDF"}
        </button>
      </div>

      <div className="grid grid-cols-2 gap-3 mt-4 text-xs">
        <div>
          <div className="text-muted case-label text-[9px] mb-0.5">Phone</div>
          <div>{report.phone || "—"}</div>
        </div>
        <div>
          <div className="text-muted case-label text-[9px] mb-0.5">Address</div>
          <div>{report.address || "—"}</div>
        </div>
      </div>

      <Section title="Summary">
        <p className="text-sm leading-relaxed text-paper/90">{report.summary}</p>
      </Section>

      <Section title="Products & Services">
        <ul className="space-y-1 text-sm">
          {report.products.length ? (
            report.products.map((p, i) => (
              <li key={i} className="flex gap-2">
                <span className="text-amber">·</span>
                {p}
              </li>
            ))
          ) : (
            <li className="text-muted">None found.</li>
          )}
        </ul>
      </Section>

      <Section title="AI-Generated Pain Points">
        <ul className="space-y-1 text-sm">
          {report.painPoints.length ? (
            report.painPoints.map((p, i) => (
              <li key={i} className="flex gap-2">
                <span className="text-teal">·</span>
                {p}
              </li>
            ))
          ) : (
            <li className="text-muted">None generated.</li>
          )}
        </ul>
      </Section>

      <Section title="Competitors">
        <div className="space-y-2">
          {report.competitors.length ? (
            report.competitors.map((c, i) => (
              <div key={i} className="border border-line rounded-md px-3 py-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="font-semibold">{c.name}</span>
                  <a href={c.website} target="_blank" rel="noreferrer" className="text-teal text-xs hover:underline">
                    {c.website}
                  </a>
                </div>
                {c.reason && <div className="text-xs text-muted mt-0.5">{c.reason}</div>}
              </div>
            ))
          ) : (
            <div className="text-muted text-sm">None identified.</div>
          )}
        </div>
      </Section>

      <div className="mt-4 pt-3 border-t border-line text-[10px] text-muted case-label">
        Model: {report.model}
      </div>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="mt-4">
      <div className="case-label text-[9px] text-muted mb-1.5">{title}</div>
      {children}
    </div>
  );
}
