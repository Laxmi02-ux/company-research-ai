import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Dossier — AI Company Research Assistant",
  description: "Give it a name or a URL. Get a full research dossier back.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="font-sans min-h-screen bg-ink text-paper antialiased">
        {children}
      </body>
    </html>
  );
}
