import * as cheerio from "cheerio";
import { CrawledPage } from "./types";

const PRIORITY_KEYWORDS = [
  "about",
  "product",
  "service",
  "solution",
  "pricing",
  "contact",
  "team",
  "company",
];

const IGNORE_KEYWORDS = [
  "login",
  "signin",
  "sign-in",
  "signup",
  "sign-up",
  "register",
  "cart",
  "checkout",
  "privacy",
  "terms",
  "cookie",
  "wp-admin",
  ".pdf",
  ".jpg",
  ".png",
  ".zip",
  "mailto:",
  "tel:",
  "javascript:",
];

const MAX_PAGES = 6;
const FETCH_TIMEOUT_MS = 8000;

async function fetchWithTimeout(url: string): Promise<string | null> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS);
  try {
    const res = await fetch(url, {
      signal: controller.signal,
      headers: {
        "User-Agent":
          "Mozilla/5.0 (compatible; DossierResearchBot/1.0; +https://example.com/bot)",
      },
    });
    if (!res.ok) return null;
    const contentType = res.headers.get("content-type") || "";
    if (!contentType.includes("text/html")) return null;
    return await res.text();
  } catch {
    return null;
  } finally {
    clearTimeout(timeout);
  }
}

function extractText($: cheerio.CheerioAPI): string {
  $("script, style, noscript, svg, iframe").remove();
  const text = $("body")
    .text()
    .replace(/\s+/g, " ")
    .trim();
  return text.slice(0, 6000); // keep payloads AI-friendly
}

function normalizeUrl(base: string, href: string): string | null {
  try {
    const u = new URL(href, base);
    u.hash = "";
    if (!["http:", "https:"].includes(u.protocol)) return null;
    return u.toString();
  } catch {
    return null;
  }
}

function score(url: string): number {
  const lower = url.toLowerCase();
  let s = 0;
  PRIORITY_KEYWORDS.forEach((k, i) => {
    if (lower.includes(k)) s += PRIORITY_KEYWORDS.length - i;
  });
  return s;
}

function shouldIgnore(url: string): boolean {
  const lower = url.toLowerCase();
  return IGNORE_KEYWORDS.some((k) => lower.includes(k));
}

/**
 * Crawl a site starting at `startUrl`. Discovers internal links,
 * ranks them by relevance (about/products/pricing/contact...),
 * dedupes, ignores login/irrelevant pages, and extracts text
 * from up to MAX_PAGES pages.
 */
export async function crawlWebsite(startUrl: string): Promise<CrawledPage[]> {
  const origin = new URL(startUrl).origin;
  const visited = new Set<string>();
  const pages: CrawledPage[] = [];

  const homeHtml = await fetchWithTimeout(startUrl);
  if (!homeHtml) return pages;

  const $home = cheerio.load(homeHtml);
  visited.add(startUrl);
  pages.push({
    url: startUrl,
    title: $home("title").first().text().trim() || "Home",
    text: extractText($home),
  });

  // Collect internal links from the homepage.
  const linkSet = new Map<string, number>();
  $home("a[href]").each((_, el) => {
    const href = $home(el).attr("href");
    if (!href) return;
    const abs = normalizeUrl(startUrl, href);
    if (!abs) return;
    if (new URL(abs).origin !== origin) return; // internal only
    if (shouldIgnore(abs)) return;
    if (visited.has(abs)) return;
    linkSet.set(abs, score(abs));
  });

  const ranked = [...linkSet.entries()]
    .sort((a, b) => b[1] - a[1])
    .map(([url]) => url)
    .slice(0, MAX_PAGES - 1);

  for (const url of ranked) {
    if (visited.has(url)) continue;
    visited.add(url);
    const html = await fetchWithTimeout(url);
    if (!html) continue;
    const $ = cheerio.load(html);
    pages.push({
      url,
      title: $("title").first().text().trim() || url,
      text: extractText($),
    });
    if (pages.length >= MAX_PAGES) break;
  }

  return pages;
}
