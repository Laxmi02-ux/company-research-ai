const OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions";

export const AVAILABLE_MODELS = [
  { id: "openai/gpt-4o-mini", label: "GPT-4o mini (fast, cheap)" },
  { id: "anthropic/claude-3.5-sonnet", label: "Claude 3.5 Sonnet" },
  { id: "google/gemini-flash-1.5", label: "Gemini 1.5 Flash" },
  { id: "meta-llama/llama-3.1-70b-instruct", label: "Llama 3.1 70B" },
  { id: "mistralai/mistral-large", label: "Mistral Large" },
];

interface AnalysisInput {
  companyNameGuess: string;
  websiteUrl: string;
  crawledText: string;
  searchSnippets: string;
  model: string;
}

export interface AIAnalysis {
  companyName: string;
  summary: string;
  products: string[];
  painPoints: string[];
  phone: string;
  address: string;
  industry: string;
  competitors: { name: string; website: string; reason: string }[];
}

const SYSTEM_PROMPT = `You are a meticulous B2B company research analyst.
You will be given raw text scraped from a company's own website, plus snippets
from public web search results. Using ONLY that evidence (do not invent facts
you cannot support), produce a structured JSON research dossier.

Return STRICT JSON ONLY, no markdown fences, no commentary, matching this shape:
{
  "companyName": string,
  "summary": string (3-5 sentences, plain business English),
  "products": string[] (key products/services, concise bullet phrases),
  "painPoints": string[] (3-6 plausible business pain points this company likely
      faces, inferred from their market position, size, and offerings),
  "phone": string (best phone number found, or "" if none),
  "address": string (best HQ/office address found, or "" if none),
  "industry": string (short industry/category label, used to find competitors),
  "competitors": [{ "name": string, "website": string, "reason": string }]
      (2-5 real, plausible competitors operating in the same country and
      industry with similar products; website must be the competitor's own
      domain, best guess if uncertain)
}`;

export async function analyzeCompany(input: AnalysisInput): Promise<AIAnalysis> {
  const apiKey = process.env.OPENROUTER_API_KEY;
  if (!apiKey) throw new Error("OPENROUTER_API_KEY is not configured");

  const userPrompt = `Company website: ${input.websiteUrl}
Best-guess company name: ${input.companyNameGuess}

=== CRAWLED WEBSITE CONTENT ===
${input.crawledText.slice(0, 12000)}

=== PUBLIC SEARCH SNIPPETS ===
${input.searchSnippets.slice(0, 4000)}

Produce the JSON dossier now.`;

  const res = await fetch(OPENROUTER_URL, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
      "HTTP-Referer": "https://company-research-ai.vercel.app",
      "X-Title": "AI Company Research Assistant",
    },
    body: JSON.stringify({
      model: input.model,
      messages: [
        { role: "system", content: SYSTEM_PROMPT },
        { role: "user", content: userPrompt },
      ],
      temperature: 0.3,
    }),
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`OpenRouter request failed: ${res.status} ${errText}`);
  }

  const data = await res.json();
  const raw: string = data?.choices?.[0]?.message?.content ?? "{}";
  const cleaned = raw.replace(/```json|```/g, "").trim();

  try {
    return JSON.parse(cleaned) as AIAnalysis;
  } catch {
    // Fallback: return a minimal, honest structure rather than throwing.
    return {
      companyName: input.companyNameGuess,
      summary:
        "The AI model returned a response that could not be parsed as structured data. Please retry, or choose a different model.",
      products: [],
      painPoints: [],
      phone: "",
      address: "",
      industry: "",
      competitors: [],
    };
  }
}
