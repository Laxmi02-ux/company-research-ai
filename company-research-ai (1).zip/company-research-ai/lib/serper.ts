const SERPER_URL = "https://google.serper.dev/search";

export interface SerperResult {
  title: string;
  link: string;
  snippet?: string;
}

async function serperSearch(query: string, num = 8): Promise<SerperResult[]> {
  const apiKey = process.env.SERPER_API_KEY;
  if (!apiKey) throw new Error("SERPER_API_KEY is not configured");

  const res = await fetch(SERPER_URL, {
    method: "POST",
    headers: {
      "X-API-KEY": apiKey,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ q: query, num }),
  });

  if (!res.ok) {
    throw new Error(`Serper request failed: ${res.status} ${res.statusText}`);
  }

  const data = await res.json();
  const organic = (data.organic || []) as any[];
  return organic.map((o) => ({
    title: o.title,
    link: o.link,
    snippet: o.snippet,
  }));
}

/** Try to resolve a company name to its official website. */
export async function findOfficialWebsite(companyName: string): Promise<{
  website: string | null;
  results: SerperResult[];
}> {
  const results = await serperSearch(`${companyName} official website`, 8);

  // Heuristics: skip well-known aggregators / social platforms.
  const blocked = [
    "wikipedia.org",
    "linkedin.com",
    "facebook.com",
    "twitter.com",
    "x.com",
    "instagram.com",
    "crunchbase.com",
    "bloomberg.com",
    "youtube.com",
    "glassdoor.com",
    "indeed.com",
  ];

  const candidate = results.find((r) => {
    try {
      const host = new URL(r.link).hostname.replace(/^www\./, "");
      return !blocked.some((b) => host.includes(b));
    } catch {
      return false;
    }
  });

  return { website: candidate ? candidate.link : null, results };
}

/** General public-info search: contact details, HQ address, etc. */
export async function searchCompanyInfo(companyName: string): Promise<SerperResult[]> {
  return serperSearch(`${companyName} headquarters address phone contact`, 8);
}

/** Search for competitors in the same space. */
export async function searchCompetitors(
  companyName: string,
  industryHint: string
): Promise<SerperResult[]> {
  const q = industryHint
    ? `${companyName} competitors alternatives ${industryHint}`
    : `${companyName} competitors alternatives`;
  return serperSearch(q, 10);
}

export { serperSearch };
