export interface CrawledPage {
  url: string;
  title: string;
  text: string;
}

export interface CompanyContact {
  phone?: string;
  address?: string;
}

export interface Competitor {
  name: string;
  website: string;
  reason?: string;
}

export interface ResearchReport {
  companyName: string;
  website: string;
  phone: string;
  address: string;
  summary: string;
  products: string[];
  painPoints: string[];
  competitors: Competitor[];
  sources: string[];
  model: string;
  generatedAt: string;
}

export interface ResearchRequestBody {
  query: string; // company name OR url
  model?: string;
}
